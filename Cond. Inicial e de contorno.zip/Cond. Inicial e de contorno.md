```python
import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
from decimal import *
```


```python
x = np.linspace(-1, 1)
t = np.linspace(0, 10)

N0 = 10
L = 2
```


```python
k1 = 1.5
k2 = 0.5

K = k1 + k2*np.sin(t)
```


```python
plt.plot(t, K)
```




    [<matplotlib.lines.Line2D at 0x23f7e86da50>]




    
![png](output_3_1.png)
    


## condições de fronteira de dirichlet


```python
Decimal(0).next_plus()
1E-308
```




    1e-308




```python
L = 1
T = 100
N0 = 20
NN = 40

t = np.linspace(1E-308, 10)
x = np.linspace(-5, 5)
k1 = 6   #deve-se impor que a capcidade suporte_max não seja maioir que o tamanho do ambiente disponível L
k2 = 4


#parametros
a = 0.010   #afunila a curva quanto maior o valor
D0 = 1
k1 = L*0.4
k2 = L*0.3
r1 = 0.5
r2 = 1.0
N0 = 10

#malha
x = np.linspace(-L, L, NN)    # mesh points in space
t = np.linspace(1E-308, T, NN)    # mesh points in time
n = len(x)
m = len(t)
h = 0.7  #define os espaçamentos dx
k = 0.24  #define os espaçamentos dt  ##para h=0.6 e k até 0.255 , rho se comporta bem, em 0.26.. já começa a colapçar




K_per = k1 + k2*np.sin(t)
K_sub = k1 + k2*np.sin(1/t)
p_inicial = N0/(L+x**2)

U1 = N0/(L + K_per)
U2 = N0/(L + K_sub)
```


```python
#plt.plot(x, p_inicial)
#plt.xlabel('x-space')
#plt.ylabel('Distrib. Inicial')

#plt.show()
```


```python
fig, (ax1,ax2, ax3) = plt.subplots(3,1)

ax1.plot(t, K, '-o')
ax1.set_ylabel('K(t)')

ax2.plot(t, U1, '-*', color = 'green')
ax2.set_ylabel('CC K_Per I')

ax3.plot(t, U2, '-', color = 'red')
ax3.set_ylabel('CC K_sub')

ax3.set_xlabel('t - tempo')

plt.show()
```


    
![png](output_8_0.png)
    



```python
#comportamento da função subarmortecida
t = np.linspace(1E-308, 100)
plt.plot(t, U2)
```




    [<matplotlib.lines.Line2D at 0x23f7e7b2950>]




    
![png](output_9_1.png)
    

